# Feature status

## Implemented in this source
- Dark space-themed Android home screen
- Android internet/network permissions and validated network status
- Offline love notes stored in SharedPreferences (up to 30)
- Local voice recording and playback
- User-confirmed cellular dialer handoff
- Configurable WSS signalling URL and six-digit room code
- WebView call screen with WebRTC camera/microphone capture, offer/answer/ICE exchange, mute/camera/end-call controls
- Node.js WebSocket signalling relay is included separately in `../backend/`

## Requires deployment and testing
- Internet video calls require a deployed WSS server; TURN is needed on some networks
- Cross-device calling has not been verified on real devices in this environment

## Not implemented yet
- Secure two-account login and server-authorized mutual-consent pairing
- Cloud sync for notes, photos, and voice notes
- Push notifications and reliable background/incoming-call service
- Voice identity verification
- Biometric app lock
- Production abuse prevention, authenticated room membership, and full privacy/security review
