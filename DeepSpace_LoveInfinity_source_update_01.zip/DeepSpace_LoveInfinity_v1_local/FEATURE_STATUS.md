# Feature status — 0.1.0

| Feature | Status | Notes |
|---|---|---|
| Branding / first screen | Implemented in source | Local UI only |
| Offline text love notes | Implemented in source | Local to this device; no sync |
| Record/play voice note | Implemented in source | Latest recording kept in app-private storage; current-session playback reference |
| Carrier voice call | Partial | Opens Android dialer; user confirms call; depends on SIM/carrier/network |
| Two-account login | Not implemented | Needs backend/auth design |
| Partner pairing and mutual consent | Not implemented | Must be server-authorized |
| Live internet video | Not implemented | Needs WebRTC or managed service plus signaling and TURN |
| Background calling | Not implemented | Needs foreground-service lifecycle and platform testing |
| Secure cloud sync | Not implemented | Backend, storage policy, TLS, authorization and tests needed |
| Voice verification | Not implemented | Requires consent-based verified model/service and fallback security |
| Biometrics / app lock | Not implemented | Android BiometricPrompt integration needed |
| Build / install verification | Not verified | No Gradle executable or Android build toolchain detected in this environment |
