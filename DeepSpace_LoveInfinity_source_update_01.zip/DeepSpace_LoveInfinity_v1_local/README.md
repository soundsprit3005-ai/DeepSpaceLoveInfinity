# DeepSpace Love∞Infinity — Android source

A local-first Android app with a dark aubergine, silver, and marigold theme. Includes local love notes, local voice recording/playback, cellular dialer handoff, internet status, and a WebRTC call screen that connects through a separately deployed secure WebSocket signalling server.

See `../SETUP_ALL_FEATURES.md` for the single-bundle setup guide and honest feature limitations.

## Build
Use Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17. The GitHub Actions workflow builds a debug APK artifact.
