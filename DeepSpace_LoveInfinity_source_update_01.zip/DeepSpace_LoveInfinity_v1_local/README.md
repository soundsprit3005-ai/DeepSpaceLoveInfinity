# Deep Space × LOVE ∞ INFINITY — Milestone 1 (local-first Android source)

This is a fresh Android Studio project created for this turn. It is an early native Kotlin milestone, not a finished production app.

## Implemented in source
- Branded dark aubergine / silver / marigold screen.
- Save and display up to 30 love notes locally using Android SharedPreferences.
- Record a voice note with microphone permission and play it during the current app session.
- Open the Android dialer with a user-entered phone number (the user reviews/places the call).
- Honest UI disclosure that network and account features are not yet connected.

## Not implemented yet
- Accounts, secure invite pairing and partner consent.
- Internet video calling / WebRTC / signaling / STUN-TURN.
- Cloud sync, offline send queue, remote image sharing or backend authorization.
- Voice identity verification, biometric app lock, encryption at rest beyond Android app sandbox defaults.
- Automated tests, a signed APK, or device testing.

## Open and build
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (Android Studio's bundled JDK is usually suitable).
2. Open this folder (`DeepSpaceLoveInfinity`) in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin and Kotlin plugin.
4. Run on an Android 8.0+ device or emulator. For voice recording, grant microphone permission.

No APK is included because a build toolchain/device build was not available in the creation environment. This project has not yet been compiled or device-tested here. Do not treat it as a release-ready secure app.
