package com.loveinfinity.deepspace

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Local-first milestone: offline love notes and voice notes, plus user-confirmed phone dialer. */
class MainActivity : Activity() {
    private val aubergine = Color.rgb(36, 21, 46)
    private val silver = Color.rgb(236, 235, 241)
    private val gold = Color.rgb(215, 166, 59)
    private lateinit var notesInput: EditText
    private lateinit var notesList: TextView
    private lateinit var phoneInput: EditText
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var recordingFile: File? = null
    private val audioPermissionRequest = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = aubergine
        window.navigationBarColor = aubergine
        val savedRecording = getSharedPreferences("voice_notes", MODE_PRIVATE).getString("latest_path", null)
        if (savedRecording != null) recordingFile = File(savedRecording).takeIf { it.exists() }
        renderScreen()
        refreshNotes()
    }

    private fun renderScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(aubergine) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "✦  DEEP SPACE"
            textSize = 13f; letterSpacing = 0.22f; setTextColor(gold)
        })
        root.addView(TextView(this).apply {
            text = "LOVE ∞ INFINITY"
            textSize = 29f; setTextColor(silver); setPadding(0, dp(8), 0, dp(3))
        })
        root.addView(TextView(this).apply {
            text = "A little space for two hearts.\nMilestone 1 · Private notes on this phone"
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(22))
        })

        section(root, "01  ·  LOVE NOTES")
        notesInput = EditText(this).apply {
            hint = "Write a note for your person…"
            minLines = 3; gravity = Gravity.TOP; textSize = 16f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(55, 39, 65))
        }
        root.addView(notesInput, matchWidth(dp(112)))
        button(root, "Save note on this phone") { saveNote() }
        button(root, "Delete all saved notes") { deleteAllNotes() }
        notesList = TextView(this).apply {
            textSize = 14f; setTextColor(silver); setPadding(0, dp(8), 0, dp(14))
        }
        root.addView(notesList, matchWidth())

        section(root, "02  ·  VOICE NOTE")
        root.addView(TextView(this).apply {
            text = "Record a short voice note and keep it locally. The latest saved recording stays available after reopening the app. It will not send to your partner yet."
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(8))
        })
        button(root, "●  Start recording") { startRecording() }
        button(root, "■  Stop and save recording") { stopRecording() }
        button(root, "▶  Play latest recording") { playRecording() }

        section(root, "03  ·  CELLULAR CALL")
        root.addView(TextView(this).apply {
            text = "Enter your partner’s number. Android will open the phone dialer for you to review and place the call. Carrier coverage and charges may apply."
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(8))
        })
        phoneInput = EditText(this).apply {
            hint = "+91… phone number"; inputType = 3
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(55, 39, 65))
        }
        root.addView(phoneInput, matchWidth(dp(54)))
        button(root, "Open phone dialer") { openDialer() }

        root.addView(TextView(this).apply {
            text = "Not connected to a server yet. Video calling, account pairing, cloud sync and voice verification are not implemented in this milestone."
            textSize = 12f; setTextColor(Color.rgb(210, 190, 215)); setPadding(0, dp(24), 0, 0)
        })
        setContentView(scroll)
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(gold)
            setPadding(0, dp(18), 0, dp(10))
        })
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label; isAllCaps = false; textSize = 14f
            setTextColor(silver); setBackgroundColor(Color.rgb(72, 49, 83))
            setOnClickListener { action() }
        }, matchWidth(dp(52)))
    }

    private fun saveNote() {
        val note = notesInput.text.toString().trim()
        if (note.isEmpty()) { toast("Write a note first."); return }
        val prefs = getSharedPreferences("love_notes", MODE_PRIVATE)
        val old = prefs.getString("items", "") ?: ""
        val updated = (listOf(note) + old.split("\n---\n").filter { it.isNotBlank() }).take(30).joinToString("\n---\n")
        prefs.edit().putString("items", updated).apply()
        notesInput.text.clear()
        refreshNotes()
        toast("Saved privately on this phone.")
    }

    private fun refreshNotes() {
        if (!::notesList.isInitialized) return
        val notes = getSharedPreferences("love_notes", MODE_PRIVATE).getString("items", "") ?: ""
        notesList.text = if (notes.isBlank()) "No saved notes yet." else "Saved notes\n\n" + notes.replace("\n---\n", "\n\n────────\n\n")
    }

    private fun deleteAllNotes() {
        val prefs = getSharedPreferences("love_notes", MODE_PRIVATE)
        if ((prefs.getString("items", "") ?: "").isBlank()) {
            toast("There are no saved notes to delete.")
            return
        }
        prefs.edit().remove("items").apply()
        refreshNotes()
        toast("All saved notes were removed from this phone.")
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        beginRecording()
    }

    @Suppress("DEPRECATION")
    private fun beginRecording() {
        try {
            recordingFile = File(filesDir, "voice-note-${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(recordingFile!!.absolutePath)
            r.prepare(); r.start(); recorder = r
            toast("Recording started. Tap stop when finished.")
        } catch (e: Exception) {
            recorder?.release(); recorder = null
            toast("Could not start recording: check microphone permission.")
        }
    }

    private fun stopRecording() {
        val r = recorder
        if (r == null) { toast("No recording is running."); return }
        try {
            r.stop()
            recordingFile?.let {
                getSharedPreferences("voice_notes", MODE_PRIVATE).edit()
                    .putString("latest_path", it.absolutePath).apply()
            }
            toast("Voice note saved on this phone.")
        } catch (_: Exception) {
            recordingFile?.delete(); toast("Recording was too short. Please try again.")
        } finally { r.release(); recorder = null }
    }

    private fun playRecording() {
        val file = recordingFile
        if (file == null || !file.exists()) { toast("Record a voice note first."); return }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { it.release(); player = null }
                prepare(); start()
            }
        } catch (_: Exception) { toast("Could not play this recording.") }
    }

    private fun openDialer() {
        val number = phoneInput.text.toString().trim()
        if (number.isBlank()) { toast("Enter a phone number first."); return }
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))) }
        catch (_: Exception) { toast("No compatible phone dialer found.") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) beginRecording()
        else if (requestCode == audioPermissionRequest) toast("Microphone permission is needed to record a voice note.")
    }

    override fun onDestroy() {
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWidth(height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height).apply { bottomMargin = dp(6) }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
