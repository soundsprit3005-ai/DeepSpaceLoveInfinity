package com.loveinfinity.deepspace

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.PermissionRequest
import android.view.View
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.io.File

/** Local-first milestone: offline love notes and voice notes, plus user-confirmed phone dialer. */
class MainActivity : Activity() {
    private val aubergine = Color.rgb(36, 21, 46)
    private val silver = Color.rgb(236, 235, 241)
    private val gold = Color.rgb(215, 166, 59)
    private lateinit var notesInput: EditText
    private lateinit var notesList: TextView
    private lateinit var phoneInput: EditText
    private lateinit var networkStatus: TextView
    private lateinit var serverInput: EditText
    private lateinit var roomInput: EditText
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var pairingCodeInput: EditText
    private lateinit var accountStatus: TextView
    private val callPermissionsRequest = 302
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var recordingFile: File? = null
    private val audioPermissionRequest = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = aubergine
        window.navigationBarColor = aubergine
        val savedRecording = getSharedPreferences("voice_notes", MODE_PRIVATE).getString("latest_path", null)
        if (savedRecording != null) recordingFile = File(savedRecording).takeIf { it.exists() }
        renderScreen()
        refreshNotes()
        refreshNetworkStatus()
    }

    private fun renderScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(aubergine) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "✦  DEEP SPACE"
            textSize = 13f; letterSpacing = 0.22f; setTextColor(gold)
        })
        root.addView(TextView(this).apply {
            text = "LOVE ∞ INFINITY"
            textSize = 29f; setTextColor(silver); setPadding(0, dp(8), 0, dp(3))
        })
        root.addView(TextView(this).apply {
            text = "A little space for two hearts.\nMilestone 2 · Internet-ready foundation"
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(10))
        })
        networkStatus = TextView(this).apply {
            textSize = 13f
            setTextColor(silver)
            setPadding(0, 0, 0, dp(14))
        }
        root.addView(networkStatus, matchWidth())

        section(root, "01  ·  ACCOUNT & PARTNER PAIRING")
        root.addView(TextView(this).apply {
            text = "Create an account or sign in to your deployed backend. Then create a pairing code on one phone and enter it on the other. Both accounts must be signed in."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(8))
        })
        emailInput = EditText(this).apply {
            hint = "Email address"; inputType = 33; setSingleLine(true); textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(55, 39, 65))
            setText(getSharedPreferences("account", MODE_PRIVATE).getString("email", "") ?: "")
        }
        root.addView(emailInput, matchWidth(dp(54)))
        passwordInput = EditText(this).apply {
            hint = "Password (10+ characters)"; inputType = 129; setSingleLine(true); textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(55, 39, 65))
        }
        root.addView(passwordInput, matchWidth(dp(54)))
        accountStatus = TextView(this).apply { textSize = 13f; setTextColor(gold); setPadding(0, dp(5), 0, dp(8)); text = accountSummary() }
        root.addView(accountStatus, matchWidth())
        button(root, "Create account") { accountRequest("/api/register") }
        button(root, "Sign in") { accountRequest("/api/login") }
        button(root, "Sign out") {
            getSharedPreferences("account", MODE_PRIVATE).edit().remove("token").remove("userId").apply()
            updateAccountStatus("Signed out on this phone.")
        }
        button(root, "Create partner pairing code") { pairingRequest(create = true) }
        pairingCodeInput = EditText(this).apply {
            hint = "Partner's 6-digit pairing code"; inputType = 2; setSingleLine(true); textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(55, 39, 65))
        }
        root.addView(pairingCodeInput, matchWidth(dp(54)))
        button(root, "Join partner with code") { pairingRequest(create = false) }

        section(root, "02  ·  PRIVATE INTERNET VIDEO CALL")
        root.addView(TextView(this).apply {
            text = "Enter your deployed backend base URL (https://...). Sign in and pair first. The app creates an authenticated call room and passes your session token to the secure WebSocket signalling service. Internet calls still require public hosting and may need TURN for some networks."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(8))
        })
        serverInput = EditText(this).apply {
            hint = "Backend URL (https://your-server.example)"
            setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(55, 39, 65))
            setText(getSharedPreferences("connection", MODE_PRIVATE).getString("server", "") ?: "")
        }
        root.addView(serverInput, matchWidth(dp(54)))
        roomInput = EditText(this).apply {
            hint = "Shared room code (6 digits)"
            setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            inputType = 2; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(55, 39, 65))
            setText(getSharedPreferences("connection", MODE_PRIVATE).getString("room", "") ?: "")
        }
        root.addView(roomInput, matchWidth(dp(54)))
        button(root, "Save backend URL") {
            val base = normalizeBaseUrl(serverInput.text.toString())
            if (base == null) toast("Enter a valid https:// backend URL.") else {
                getSharedPreferences("connection", MODE_PRIVATE).edit().putString("server", base).apply()
                serverInput.setText(base); toast("Backend URL saved on this phone.")
            }
        }
        button(root, "Save server and room") {
            getSharedPreferences("connection", MODE_PRIVATE).edit()
                .putString("server", serverInput.text.toString().trim())
                .putString("room", roomInput.text.toString().trim()).apply()
            toast("Connection settings saved on this phone.")
        }
        button(root, "Start authenticated video call") { createCallRoomAndStart() }

        section(root, "03  ·  LOVE NOTES")
        notesInput = EditText(this).apply {
            hint = "Write a note for your person…"
            minLines = 3; gravity = Gravity.TOP; textSize = 16f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(55, 39, 65))
        }
        root.addView(notesInput, matchWidth(dp(112)))
        button(root, "Save note on this phone") { saveNote() }
        button(root, "Delete all saved notes") { deleteAllNotes() }
        notesList = TextView(this).apply {
            textSize = 14f; setTextColor(silver); setPadding(0, dp(8), 0, dp(14))
        }
        root.addView(notesList, matchWidth())

        section(root, "04  ·  VOICE NOTE")
        root.addView(TextView(this).apply {
            text = "Record a short voice note and keep it locally. The latest saved recording stays available after reopening the app. It will not send to your partner yet."
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(8))
        })
        button(root, "●  Start recording") { startRecording() }
        button(root, "■  Stop and save recording") { stopRecording() }
        button(root, "▶  Play latest recording") { playRecording() }

        section(root, "05  ·  CELLULAR CALL")
        root.addView(TextView(this).apply {
            text = "Enter your partner’s number. Android will open the phone dialer for you to review and place the call. Carrier coverage and charges may apply."
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(8))
        })
        phoneInput = EditText(this).apply {
            hint = "+91… phone number"; inputType = 3
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(55, 39, 65))
        }
        root.addView(phoneInput, matchWidth(dp(54)))
        button(root, "Open phone dialer") { openDialer() }

        root.addView(TextView(this).apply {
            text = "This build now includes Android-side registration/login, authenticated pairing-code calls to the backend, and a token-authenticated signalling connection. Cloud memory sync, verified voice identity, biometric lock, background incoming calls and TURN relay configuration remain separate milestones and require deployment/testing."
            textSize = 12f; setTextColor(Color.rgb(210, 190, 215)); setPadding(0, dp(24), 0, 0)
        })
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        if (::networkStatus.isInitialized) refreshNetworkStatus()
    }

    private fun refreshNetworkStatus() {
        if (!::networkStatus.isInitialized) return
        val manager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork
        val capabilities = network?.let { manager.getNetworkCapabilities(it) }
        val hasInternet = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val validated = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        if (hasInternet && validated) {
            networkStatus.text = "● Internet connected · Ready for online features once a server is configured"
            networkStatus.setTextColor(Color.rgb(150, 220, 170))
        } else {
            networkStatus.text = "○ No verified internet connection · Turn on Wi-Fi or mobile data"
            networkStatus.setTextColor(Color.rgb(255, 190, 150))
        }
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(gold)
            setPadding(0, dp(18), 0, dp(10))
        })
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label; isAllCaps = false; textSize = 14f
            setTextColor(silver); setBackgroundColor(Color.rgb(72, 49, 83))
            setOnClickListener { action() }
        }, matchWidth(dp(52)))
    }

    private fun saveNote() {
        val note = notesInput.text.toString().trim()
        if (note.isEmpty()) { toast("Write a note first."); return }
        val prefs = getSharedPreferences("love_notes", MODE_PRIVATE)
        val old = prefs.getString("items", "") ?: ""
        val updated = (listOf(note) + old.split("\n---\n").filter { it.isNotBlank() }).take(30).joinToString("\n---\n")
        prefs.edit().putString("items", updated).apply()
        notesInput.text.clear()
        refreshNotes()
        toast("Saved privately on this phone.")
    }

    private fun refreshNotes() {
        if (!::notesList.isInitialized) return
        val notes = getSharedPreferences("love_notes", MODE_PRIVATE).getString("items", "") ?: ""
        notesList.text = if (notes.isBlank()) "No saved notes yet." else "Saved notes\n\n" + notes.replace("\n---\n", "\n\n────────\n\n")
    }

    private fun deleteAllNotes() {
        val prefs = getSharedPreferences("love_notes", MODE_PRIVATE)
        if ((prefs.getString("items", "") ?: "").isBlank()) {
            toast("There are no saved notes to delete.")
            return
        }
        prefs.edit().remove("items").apply()
        refreshNotes()
        toast("All saved notes were removed from this phone.")
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        beginRecording()
    }

    @Suppress("DEPRECATION")
    private fun beginRecording() {
        try {
            recordingFile = File(filesDir, "voice-note-${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(recordingFile!!.absolutePath)
            r.prepare(); r.start(); recorder = r
            toast("Recording started. Tap stop when finished.")
        } catch (e: Exception) {
            recorder?.release(); recorder = null
            toast("Could not start recording: check microphone permission.")
        }
    }

    private fun stopRecording() {
        val r = recorder
        if (r == null) { toast("No recording is running."); return }
        try {
            r.stop()
            recordingFile?.let {
                getSharedPreferences("voice_notes", MODE_PRIVATE).edit()
                    .putString("latest_path", it.absolutePath).apply()
            }
            toast("Voice note saved on this phone.")
        } catch (_: Exception) {
            recordingFile?.delete(); toast("Recording was too short. Please try again.")
        } finally { r.release(); recorder = null }
    }

    private fun playRecording() {
        val file = recordingFile
        if (file == null || !file.exists()) { toast("Record a voice note first."); return }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { it.release(); player = null }
                prepare(); start()
            }
        } catch (_: Exception) { toast("Could not play this recording.") }
    }


    private fun createCallRoomAndStart() {
        val token = getSharedPreferences("account", MODE_PRIVATE).getString("token", null)
        if (token.isNullOrBlank()) { toast("Create an account or sign in first."); return }
        val base = normalizeBaseUrl(serverInput.text.toString())
        if (base == null) { toast("Enter your deployed https:// backend URL first."); return }
        getSharedPreferences("connection", MODE_PRIVATE).edit().putString("server", base).apply()
        serverInput.setText(base)
        toast("Requesting a secure call room…")
        apiRequest("POST", "/api/call-room", token, JSONObject()) { ok, body ->
            if (!ok) { toast(body.optString("error", "Could not create call room. Pair with your partner first.")); return@apiRequest }
            val room = body.optString("room", "")
            if (!room.matches(Regex("\\d{6}"))) { toast("Backend returned an invalid call room."); return@apiRequest }
            roomInput.setText(room)
            getSharedPreferences("connection", MODE_PRIVATE).edit().putString("room", room).apply()
            requestCallPermissionsAndOpen()
        }
    }

    private fun requestCallPermissionsAndOpen() {
        val server = normalizeBaseUrl(serverInput.text.toString())
        val room = roomInput.text.toString().trim()
        val token = getSharedPreferences("account", MODE_PRIVATE).getString("token", "") ?: ""
        if (server == null || !room.matches(Regex("\\d{6}")) || token.isBlank()) { toast("Sign in, pair with your partner, and create a call room first."); return }
        getSharedPreferences("connection", MODE_PRIVATE).edit().putString("server", server).putString("room", room).apply()
        val missing = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CAMERA)
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), callPermissionsRequest) else openVideoCall()
    }

    private fun openVideoCall() {
        val prefs = getSharedPreferences("connection", MODE_PRIVATE)
        val base = normalizeBaseUrl(prefs.getString("server", "") ?: "") ?: ""
        val room = prefs.getString("room", "") ?: ""
        val token = getSharedPreferences("account", MODE_PRIVATE).getString("token", "") ?: ""
        val wsServer = base.replaceFirst(Regex("^https://", RegexOption.IGNORE_CASE), "wss://")
            .replaceFirst(Regex("^http://", RegexOption.IGNORE_CASE), "ws://")
        val webView = WebView(this).apply {
            setBackgroundColor(aubergine)
            settings.javaScriptEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val granted = request.resources.all { resource ->
                            (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) ||
                            (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                        }
                        if (granted) request.grant(request.resources) else request.deny()
                    }
                }
            }
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/call.html?server=" + Uri.encode(wsServer) + "&room=" + Uri.encode(room) + "&token=" + Uri.encode(token))
        }
        val wrapper = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(aubergine) }
        val back = Button(this).apply { text = "← Back to LOVE ∞ INFINITY"; isAllCaps = false; setOnClickListener { webView.destroy(); renderScreen(); refreshNotes(); refreshNetworkStatus() } }
        wrapper.addView(back, matchWidth(dp(52)))
        wrapper.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(wrapper)
    }

    private fun accountRequest(path: String) {
        val email = emailInput.text.toString().trim()
        val password = passwordInput.text.toString()
        if (email.isBlank() || password.length < 10) { toast("Enter your email and a password of at least 10 characters."); return }
        val base = normalizeBaseUrl(serverInput.text.toString())
        if (base == null) { toast("Enter and save your deployed https:// backend URL first."); return }
        getSharedPreferences("connection", MODE_PRIVATE).edit().putString("server", base).apply()
        serverInput.setText(base)
        val payload = JSONObject().put("email", email).put("password", password)
        apiRequest("POST", path, null, payload) { ok, body ->
            if (!ok) { toast(body.optString("error", "Account request failed.")); return@apiRequest }
            val user = body.optJSONObject("user")
            getSharedPreferences("account", MODE_PRIVATE).edit()
                .putString("token", body.optString("token"))
                .putString("userId", user?.optString("id", "") ?: "")
                .putString("email", user?.optString("email", email) ?: email).apply()
            passwordInput.text.clear()
            updateAccountStatus("Signed in as $email · paired: ${user?.optBoolean("paired", false) ?: false}")
            toast(if (path.endsWith("register")) "Account created and signed in." else "Signed in successfully.")
        }
    }

    private fun pairingRequest(create: Boolean) {
        val token = getSharedPreferences("account", MODE_PRIVATE).getString("token", null)
        if (token.isNullOrBlank()) { toast("Sign in first."); return }
        val path: String
        val payload: JSONObject
        if (create) { path = "/api/pair/create"; payload = JSONObject() }
        else {
            val code = pairingCodeInput.text.toString().trim()
            if (!code.matches(Regex("\\d{6}"))) { toast("Enter the 6-digit code shown on your partner's phone."); return }
            path = "/api/pair/join"; payload = JSONObject().put("code", code)
        }
        apiRequest("POST", path, token, payload) { ok, body ->
            if (!ok) { toast(body.optString("error", "Pairing failed.")); return@apiRequest }
            if (create) {
                val code = body.optString("code")
                pairingCodeInput.setText(code)
                updateAccountStatus("Pairing code: $code · expires in 10 minutes")
                toast("Share this pairing code privately with your partner.")
            } else {
                updateAccountStatus("Partner paired: ${body.optJSONObject("partner")?.optString("email", "connected")}")
                pairingCodeInput.text.clear()
                toast("Partner accounts paired successfully.")
            }
        }
    }

    private fun apiRequest(method: String, path: String, token: String?, payload: JSONObject, done: (Boolean, JSONObject) -> Unit) {
        val base = normalizeBaseUrl(getSharedPreferences("connection", MODE_PRIVATE).getString("server", "") ?: "")
        if (base == null) { done(false, JSONObject().put("error", "Invalid backend URL")); return }
        Thread {
            var connection: HttpURLConnection? = null
            var success = false
            var result = JSONObject()
            try {
                connection = (URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method; connectTimeout = 12000; readTimeout = 12000
                    setRequestProperty("Accept", "application/json")
                    if (token != null) setRequestProperty("Authorization", "Bearer $token")
                    if (method == "POST" || method == "PUT") {
                        doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        OutputStreamWriter(outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
                    }
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                result = try { JSONObject(text) } catch (_: Exception) { JSONObject().put("error", "Backend returned an unreadable response") }
                success = code in 200..299
            } catch (e: Exception) {
                result = JSONObject().put("error", "Cannot reach backend: ${e.message ?: "network error"}")
            } finally { connection?.disconnect() }
            val finalSuccess = success; val finalResult = result
            runOnUiThread { done(finalSuccess, finalResult) }
        }.start()
    }

    private fun normalizeBaseUrl(value: String): String? {
        val v = value.trim().trimEnd('/')
        if (!(v.startsWith("https://", true) || v.startsWith("http://", true))) return null
        if (v.any { it.isWhitespace() }) return null
        return v
    }

    private fun accountSummary(): String {
        val prefs = getSharedPreferences("account", MODE_PRIVATE)
        val email = prefs.getString("email", null)
        val token = prefs.getString("token", null)
        return if (!token.isNullOrBlank() && !email.isNullOrBlank()) "Signed in as $email" else "Not signed in"
    }

    private fun updateAccountStatus(text: String) {
        if (::accountStatus.isInitialized) accountStatus.text = text
    }

    private fun openDialer() {
        val number = phoneInput.text.toString().trim()
        if (number.isBlank()) { toast("Enter a phone number first."); return }
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))) }
        catch (_: Exception) { toast("No compatible phone dialer found.") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) beginRecording()
        else if (requestCode == audioPermissionRequest) toast("Microphone permission is needed to record a voice note.")
        else if (requestCode == callPermissionsRequest && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) openVideoCall()
        else if (requestCode == callPermissionsRequest) toast("Camera and microphone permissions are needed for video calls.")
    }

    override fun onDestroy() {
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWidth(height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height).apply { bottomMargin = dp(6) }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
