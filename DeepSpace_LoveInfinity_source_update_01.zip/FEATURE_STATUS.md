# Feature status — updated integration milestone

| Feature | State | Notes |
|---|---|---|
| Space-themed Android home screen | Included | Native Android source |
| Offline love notes | Included | Stored on this phone only |
| Voice note recording/playback | Included | Local recording only |
| Cellular call | Partial | Opens dialer; user confirms |
| Android registration/login UI | Implemented in source; unbuilt | Calls backend REST routes; requires deployed HTTPS backend |
| Partner pairing UI | Implemented in source; unbuilt | Create/join short-lived invitation codes |
| Authenticated call-room request | Implemented in source; unbuilt | Requires both partners to request the active room during its 15-minute window |
| Token-authenticated WebSocket signalling | Implemented in source; unbuilt | Requires HTTPS/WSS hosting; token is passed as query parameter for this prototype |
| WebRTC video-call UI | Included in source | Uses public STUN only; some networks need TURN |
| Android build | Not verified here | Run the GitHub Actions build after placing project contents at repository root |
| Backend live deployment | Not done | No live server URL or secrets are included |
| Two-device calls | Not verified | Must be tested on two real devices with deployed backend |
| Cloud sync of notes/photos/voice notes | Not complete | Backend memories API exists, but Android notes/media are not synced |
| Push/background incoming calls | Not implemented | Requires push + native lifecycle work |
| Voice identity verification | Not implemented | Voice recording is not speaker authentication |
| Biometric lock | Not implemented | No biometric gate currently |
| Automatic reconnect | Not implemented | Not production-ready |

**Do not describe this milestone as a complete app.** It wires the first login/pairing/call-room path in source, but requires build, deployment, and two-device verification. The current backend JSON store is a development store, not a production database.
