# DeepSpace LOVE ∞ INFINITY — integrated milestone

This bundle updates the Android client so the first backend path is connected in source:

1. Android registration and login call `POST /api/register` and `POST /api/login`.
2. Pairing code creation/join call the authenticated backend routes.
3. The app requests a call room from the backend and passes the session token to the WebSocket signalling endpoint.
4. The backend reuses the same short-lived room for the same paired accounts so both phones can join it during the 15-minute window.

## Existing GitHub Actions workflow compatibility

The ZIP `DeepSpace_LoveInfinity_source_update_01.zip` is structured with `DeepSpace_LoveInfinity_v1_local/` at its root, so the existing workflow that extracts it and builds `source/DeepSpace_LoveInfinity_v1_local` can keep using the same archive filename. Replace the old ZIP in your repository with this ZIP, commit/push, then check Actions. Do not upload the ZIP inside itself.

## Backend deployment

Use `backend/README.md`. Deploy Node.js 20+ behind HTTPS/WSS, set `TOKEN_SECRET` to a random secret of at least 32 characters, and configure a persistent `DATA_FILE`. The app's server field expects the public HTTPS base URL (for example `https://your-service.example`); it derives WSS for signalling.

## Honest verification status

- `node --check` passed for backend JavaScript and the call-page JavaScript.
- ZIP integrity is checked when packaged.
- Android Gradle build could not be run in this environment because Gradle/Android SDK build tooling is not installed here.
- No backend has been deployed and no two-device call has been tested here. You must run the GitHub Actions build and test on both phones.
- This is not yet the complete app: cloud memory sync from Android, photo/voice media sync, push/background incoming calls, biometric lock, voice identity verification, TURN relay configuration and robust reconnection are still outstanding.
