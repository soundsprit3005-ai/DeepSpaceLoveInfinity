# DeepSpace backend (development implementation)

This Node.js service now contains API routes for email/password registration and login, session tokens, six-digit partner invitation codes, mutual pairing, authenticated memory JSON storage, short-lived paired-call room codes, and authenticated WebSocket signalling. It uses Node's built-in `scrypt` password hashing and HMAC-hashed random session tokens. The JSON data file is a development store, not a production database.

## Run locally

Requires Node.js 20+.

```sh
npm install
export TOKEN_SECRET="replace-with-a-random-secret-at-least-32-characters-long"
npm start
```

Set `DATA_FILE` to a persistent writable path when deploying. Never commit `data.json` or a real secret. Put the service behind a host that provides HTTPS/WSS; do not expose plain HTTP/WebSocket traffic on the public internet. Add rate limiting, email verification, password reset, abuse controls, database backups, encrypted storage, and security review before real personal use.

## Routes

- `POST /api/register` `{ "email": "...", "password": "10+ characters" }`
- `POST /api/login` `{ "email": "...", "password": "..." }`
- `GET /api/me` with `Authorization: Bearer TOKEN`
- `POST /api/pair/create` with bearer token → short-lived code
- `POST /api/pair/join` with bearer token and `{ "code": "123456" }` → mutual pair
- `POST /api/call-room` with bearer token → short-lived six-digit room for paired accounts
- `GET /api/memories` / `PUT /api/memories` with bearer token
- `POST /api/logout` with bearer token
- `GET /health`
- `wss://HOST/signal?token=TOKEN` WebSocket; send `{ "type":"join", "room":"123456" }`, then relay WebRTC `offer`, `answer`, `candidate`, `leave` messages.

## Current integration status

The Android source now includes registration/login requests, pairing-code create/join actions, a request for an authenticated call room, and passes the session token to the WebSocket signalling URL. Both paired phones must request the call room during its 15-minute validity window; the backend returns the same active room to the same pair. This is a manual-start prototype, not push-based incoming calling. Android compilation, backend deployment, and two-device calling have not been verified in this environment. The JSON file store is for development only; use persistent storage and complete a security review before real personal data.
