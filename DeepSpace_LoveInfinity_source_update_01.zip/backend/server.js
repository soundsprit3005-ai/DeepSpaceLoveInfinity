'use strict';
// Development backend for DeepSpace LOVE ∞ INFINITY.
// Requires HTTPS/WSS termination at the hosting provider for public deployment.
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 3000);
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const TOKEN_SECRET = process.env.TOKEN_SECRET;
if (!TOKEN_SECRET || TOKEN_SECRET.length < 32) {
  console.error('Set TOKEN_SECRET to a random secret of at least 32 characters before starting.');
  process.exit(1);
}
const sessions = new Map();
const rooms = new Map();
const callRooms = new Map();
const activePairRooms = new Map();
let db = { users: {}, pairInvites: {}, memories: {} };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) }; } catch (e) { if (e.code !== 'ENOENT') throw e; }
function persist() { const tmp = DATA_FILE + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 }); fs.renameSync(tmp, DATA_FILE); }
function id(bytes = 24) { return crypto.randomBytes(bytes).toString('base64url'); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex'); return { salt, hash };
}
function safeEqual(a, b) { const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b)); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); }
function issueToken(userId) { const token = id(32); sessions.set(crypto.createHmac('sha256', TOKEN_SECRET).update(token).digest('hex'), { userId, expires: Date.now() + 7 * 86400000 }); return token; }
function tokenUser(token) { if (!token) return null; const key = crypto.createHmac('sha256', TOKEN_SECRET).update(token).digest('hex'); const s = sessions.get(key); if (!s || s.expires < Date.now()) { sessions.delete(key); return null; } return s.userId; }
function bearer(req) { const m = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || ''); return m && m[1]; }
function json(res, status, body) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }); res.end(JSON.stringify(body)); }
async function readBody(req) { let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > 256 * 1024) throw Object.assign(new Error('Request too large'), { status: 413 }); } try { return raw ? JSON.parse(raw) : {}; } catch { throw Object.assign(new Error('Invalid JSON'), { status: 400 }); } }
function currentPair(userId) { const u = db.users[userId]; return u && u.partnerId && db.users[u.partnerId] ? u.partnerId : null; }
function auth(req, res) { const uid = tokenUser(bearer(req)); if (!uid || !db.users[uid]) { json(res, 401, { error: 'Sign in required' }); return null; } return uid; }
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/health')) return json(res, 200, { service: 'DeepSpace LoveInfinity backend', status: 'ok' });
  try {
    if (req.method === 'POST' && url.pathname === '/api/register') {
      const b = await readBody(req); const email = String(b.email || '').trim().toLowerCase(); const password = String(b.password || '');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10 || password.length > 200) return json(res, 400, { error: 'Use a valid email and password of 10–200 characters' });
      if (Object.values(db.users).some(u => u.email === email)) return json(res, 409, { error: 'Account already exists' });
      const uid = id(16); const p = hashPassword(password); db.users[uid] = { id: uid, email, salt: p.salt, passwordHash: p.hash, partnerId: null, createdAt: new Date().toISOString() }; persist();
      return json(res, 201, { token: issueToken(uid), user: { id: uid, email, paired: false } });
    }
    if (req.method === 'POST' && url.pathname === '/api/login') {
      const b = await readBody(req); const email = String(b.email || '').trim().toLowerCase(); const password = String(b.password || ''); const u = Object.values(db.users).find(x => x.email === email);
      if (!u || !safeEqual(hashPassword(password, u.salt).hash, u.passwordHash)) return json(res, 401, { error: 'Email or password is incorrect' });
      return json(res, 200, { token: issueToken(u.id), user: { id: u.id, email: u.email, paired: !!currentPair(u.id) } });
    }
    if (req.method === 'GET' && url.pathname === '/api/me') { const uid = auth(req, res); if (!uid) return; const u = db.users[uid]; return json(res, 200, { user: { id: uid, email: u.email, paired: !!currentPair(uid) } }); }
    if (req.method === 'POST' && url.pathname === '/api/pair/create') {
      const uid = auth(req, res); if (!uid) return; if (currentPair(uid)) return json(res, 409, { error: 'Account is already paired' });
      for (const [code, invite] of Object.entries(db.pairInvites)) if (invite.userId === uid || invite.expires < Date.now()) delete db.pairInvites[code];
      let code; do { code = String(crypto.randomInt(100000, 1000000)); } while (db.pairInvites[code]);
      db.pairInvites[code] = { userId: uid, expires: Date.now() + 10 * 60 * 1000 }; persist(); return json(res, 201, { code, expiresInSeconds: 600 });
    }
    if (req.method === 'POST' && url.pathname === '/api/pair/join') {
      const uid = auth(req, res); if (!uid) return; const b = await readBody(req); const code = String(b.code || ''); const invite = db.pairInvites[code];
      if (!invite || invite.expires < Date.now()) { delete db.pairInvites[code]; persist(); return json(res, 404, { error: 'Pair code is invalid or expired' }); }
      if (invite.userId === uid) return json(res, 400, { error: 'You cannot pair an account with itself' });
      if (currentPair(uid) || currentPair(invite.userId)) return json(res, 409, { error: 'One account is already paired' });
      db.users[uid].partnerId = invite.userId; db.users[invite.userId].partnerId = uid; delete db.pairInvites[code]; persist(); return json(res, 200, { paired: true, partner: { id: invite.userId, email: db.users[invite.userId].email } });
    }
    if (req.method === 'POST' && url.pathname === '/api/call-room') {
      const uid = auth(req, res); if (!uid) return; const partnerId = currentPair(uid);
      if (!partnerId) return json(res, 403, { error: 'Pair with your partner first' });
      for (const [code, room] of callRooms) {
        if (room.expires < Date.now()) {
          callRooms.delete(code);
          const key = room.users.slice().sort().join(':');
          if (activePairRooms.get(key) === code) activePairRooms.delete(key);
        }
      }
      const pairKey = [uid, partnerId].sort().join(':');
      const existingCode = activePairRooms.get(pairKey);
      const existingRoom = existingCode ? callRooms.get(existingCode) : null;
      if (existingRoom && existingRoom.expires > Date.now()) {
        return json(res, 200, { room: existingCode, expiresInSeconds: Math.max(1, Math.floor((existingRoom.expires - Date.now()) / 1000)) });
      }
      let code; do { code = String(crypto.randomInt(100000, 1000000)); } while (callRooms.has(code));
      callRooms.set(code, { users: [uid, partnerId].sort(), expires: Date.now() + 15 * 60 * 1000 });
      activePairRooms.set(pairKey, code);
      return json(res, 201, { room: code, expiresInSeconds: 900 });
    }
    if (req.method === 'GET' && url.pathname === '/api/memories') { const uid = auth(req, res); if (!uid) return; return json(res, 200, { memories: db.memories[uid] || [] }); }
    if (req.method === 'PUT' && url.pathname === '/api/memories') {
      const uid = auth(req, res); if (!uid) return; const b = await readBody(req); if (!Array.isArray(b.memories) || b.memories.length > 100 || Buffer.byteLength(JSON.stringify(b.memories)) > 200000) return json(res, 400, { error: 'Memories must be an array of at most 100 items and 200 KB' });
      db.memories[uid] = b.memories; persist(); return json(res, 200, { saved: true, count: b.memories.length });
    }
    if (req.method === 'POST' && url.pathname === '/api/logout') { const uid = auth(req, res); if (!uid) return; const tok = bearer(req); sessions.delete(crypto.createHmac('sha256', TOKEN_SECRET).update(tok).digest('hex')); return json(res, 200, { loggedOut: true }); }
    return json(res, 404, { error: 'Not found' });
  } catch (e) { return json(res, e.status || 500, { error: e.status ? e.message : 'Internal server error' }); }
});
const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname !== '/signal') { socket.write('HTTP/1.1 404 Not Found\r\n\r\n'); socket.destroy(); return; }
  const uid = tokenUser(url.searchParams.get('token'));
  if (!uid || !currentPair(uid)) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return; }
  req.userId = uid; wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});
function send(ws, msg) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); }
function remove(ws) { const room = ws.roomCode; if (!room) return; const peers = rooms.get(room); if (!peers) return; peers.delete(ws); for (const peer of peers) send(peer, { type: 'peer-left' }); if (!peers.size) rooms.delete(room); ws.roomCode = null; }
wss.on('connection', (ws, req) => {
  ws.userId = req.userId;
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { send(ws, { type: 'error', message: 'Invalid message' }); return; }
    if (msg.type === 'join') {
      const room = String(msg.room || ''); const roomInfo = callRooms.get(room); if (!/^\d{6}$/.test(room) || !roomInfo || roomInfo.expires < Date.now() || !roomInfo.users.includes(ws.userId)) { send(ws, { type: 'error', message: 'Call code is invalid, expired, or not assigned to this account' }); ws.close(); return; }
      if (ws.roomCode) remove(ws); let peers = rooms.get(room); if (!peers) { peers = new Set(); rooms.set(room, peers); }
      if (peers.size >= 2 || [...peers].some(p => p.userId === ws.userId)) { send(ws, { type: 'error', message: 'Call room is full or duplicate device' }); ws.close(); return; }
      const allowed = roomInfo.users.includes(ws.userId) && [...peers].every(p => roomInfo.users.includes(p.userId) && currentPair(p.userId) === ws.userId) && (!peers.size || currentPair(ws.userId) === [...peers][0].userId);
      if (!allowed) { send(ws, { type: 'error', message: 'Only mutually paired accounts may call' }); ws.close(); return; }
      const initiator = peers.size === 1; peers.add(ws); ws.roomCode = room; send(ws, { type: 'ready', initiator }); for (const peer of peers) if (peer !== ws) send(peer, { type: 'peer-joined' }); return;
    }
    if (!ws.roomCode) { send(ws, { type: 'error', message: 'Join a call room first' }); return; }
    if (!['offer', 'answer', 'candidate', 'leave'].includes(msg.type)) { send(ws, { type: 'error', message: 'Unsupported message' }); return; }
    const peers = rooms.get(ws.roomCode); if (!peers) return; if (msg.type === 'leave') { remove(ws); return; }
    const outgoing = { type: msg.type }; if (msg.type === 'offer' || msg.type === 'answer') outgoing.sdp = msg.sdp; if (msg.type === 'candidate') outgoing.candidate = msg.candidate;
    for (const peer of peers) if (peer !== ws) send(peer, outgoing);
  });
  ws.on('close', () => remove(ws)); ws.on('error', () => remove(ws));
});
server.listen(PORT, '0.0.0.0', () => console.log(`DeepSpace backend listening on ${PORT}`));
